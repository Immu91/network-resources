﻿Connect-AzAccount 
Select-AzSubscription -SubscriptionName '281-RE-Grid-Vaults-HR-Azure-Prod-EU' 
$rgName = 'UAI3045101-PRECEPTION-VAULT-PROD-RG' 
$vmName = 'lisdev43v'  
$vm = Get-AzVM -ResourceGroupName $rgName -Name $vmName
Stop-AzVM -ResourceGroupName $rgName -Name $vmName
$vm.StorageProfile.OSDisk.DiskSizeGB = 129 
Update-AzVM -ResourceGroupName $rgName -VM $vm 
Start-AzVM -ResourceGroupName $rgName -Name $vmName
